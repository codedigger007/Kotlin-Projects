package com.example.mockexam

//@Entity(tableName = "lagos_data")
data class LagosData(val items: List<LagosSecondData>)